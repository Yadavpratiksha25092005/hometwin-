package com.hometwin.home_digital_twin

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import com.google.ar.core.ArCoreApk
import com.google.ar.core.exceptions.UnavailableUserDeclinedInstallationException
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

/**
 * Flutter <-> native bridge for the ARCore room scanner.
 *   isSupported -> "supported" | "needs_install" | "checking" | "unsupported"
 *   startScan   -> JSON string (scan result) | null (user cancelled) | error
 */
class MainActivity : FlutterActivity() {
    private var pending: MethodChannel.Result? = null
    private var cameraPending: MethodChannel.Result? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "isSupported" -> {
                    val a = ArCoreApk.getInstance().checkAvailability(this)
                    result.success(
                        when {
                            a.isSupported -> "supported"
                            a.isTransient -> "checking"
                            a == ArCoreApk.Availability.SUPPORTED_NOT_INSTALLED ||
                                a == ArCoreApk.Availability.SUPPORTED_APK_TOO_OLD -> "needs_install"
                            else -> "unsupported"
                        }
                    )
                }
                "startScan" -> {
                    if (pending != null) {
                        result.error("busy", "A scan is already in progress", null)
                    } else {
                        pending = result
                        startActivityForResult(Intent(this, ScanActivity::class.java), REQ_SCAN)
                    }
                }
                // Live AR furniture preview: ARCore installed + camera permission granted?
                // -> "ready" | "unsupported" | "install_requested" | "declined" | "denied" | "checking"
                "prepareAr" -> prepareAr(result)
                else -> result.notImplemented()
            }
        }
    }

    private fun prepareAr(result: MethodChannel.Result) {
        val a = ArCoreApk.getInstance().checkAvailability(this)
        if (a.isTransient) { result.success("checking"); return }
        if (!a.isSupported && a != ArCoreApk.Availability.SUPPORTED_NOT_INSTALLED &&
            a != ArCoreApk.Availability.SUPPORTED_APK_TOO_OLD) { result.success("unsupported"); return }
        try {
            if (ArCoreApk.getInstance().requestInstall(this, true) == ArCoreApk.InstallStatus.INSTALL_REQUESTED) {
                result.success("install_requested"); return
            }
        } catch (e: UnavailableUserDeclinedInstallationException) {
            result.success("declined"); return
        } catch (e: Exception) {
            result.success("unsupported"); return
        }
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            result.success("ready")
        } else if (cameraPending != null) {
            result.error("busy", "Camera permission request already in progress", null)
        } else {
            cameraPending = result
            requestPermissions(arrayOf(Manifest.permission.CAMERA), REQ_CAMERA)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_CAMERA) return
        val r = cameraPending ?: return
        cameraPending = null
        r.success(if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) "ready" else "denied")
    }

    @Deprecated("FlutterActivity is a plain Activity; classic result API is fine here")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_SCAN) return
        val r = pending ?: return
        pending = null
        val json = data?.getStringExtra(ScanActivity.EXTRA_JSON)
        val err = data?.getStringExtra(ScanActivity.EXTRA_ERROR)
        when {
            resultCode == RESULT_OK && json != null -> r.success(json)
            err != null -> r.error("scan_failed", err, null)
            else -> r.success(null) // cancelled
        }
    }

    companion object {
        const val CHANNEL = "hometwin/room_scan"
        const val REQ_SCAN = 4711
        const val REQ_CAMERA = 4712
    }
}