import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_sceneview/flutter_sceneview.dart';
import '../main.dart';

/// Live AR furniture preview (SceneView + ARCore): find the floor, pick a piece, tap to place it,
/// then drag / twist / pinch it. Android only; other devices see a short explanation.
enum _Ar { checking, ready, unsupported, needsInstall, denied, notAndroid }

class _Item {
  final String name, model, thumb;
  final double size; // largest dimension in metres
  const _Item(this.name, this.model, this.thumb, this.size);
}

/// Picker items. To use a real model: drop a .glb with the same name into assets/ar/ and set `size`
/// (the model's largest dimension in metres - SceneView scales it to this size).
const _items = [
  _Item('Modern Sofa', 'assets/ar/modern_sofa.glb', 'assets/images/demo/sofa1.jpg', 2.2),
  _Item('L-Shaped Sofa', 'assets/ar/l_sofa.glb', 'assets/images/demo/sofa2.jpg', 2.6),
  _Item('Leather Sofa', 'assets/ar/leather_sofa.glb', 'assets/images/demo/sofa3.jpg', 2.0),
  _Item('Armchair', 'assets/ar/armchair.glb', 'assets/ar/armchair.png', 0.9),
  _Item('Vintage Day Bed', 'assets/ar/daybed.glb', 'assets/ar/daybed.png', 2.0),
];

class ArPreviewScreen extends StatefulWidget {
  const ArPreviewScreen({super.key});
  @override
  State<ArPreviewScreen> createState() => _ArPreviewScreenState();
}

class _ArPreviewScreenState extends State<ArPreviewScreen> {
  static const _ch = MethodChannel('hometwin/room_scan');
  static const _findHint = 'Stand about 2 m back and point at the floor. When dots appear, TAP the floor once to place the furniture';
  static const _gestureHint = 'Drag to move  •  Twist with two fingers to rotate  •  Pinch to resize';

  final _controller = SceneViewController();
  final _placed = <PlacedModel>[];
  _Ar _ar = _Ar.checking;
  int _sel = 0;
  String _hint = _findHint;

  @override
  void initState() {
    super.initState();
    _prepare();
  }

  /// Checks ARCore, asks for the camera permission, then shows the live view.
  Future<void> _prepare() async {
    setState(() => _ar = _Ar.checking);
    if (kIsWeb || !Platform.isAndroid) {
      setState(() => _ar = _Ar.notAndroid);
      return;
    }
    var r = 'unsupported';
    try {
      for (var i = 0; i < 4; i++) {
        r = await _ch.invokeMethod<String>('prepareAr') ?? 'unsupported';
        if (r != 'checking') break;
        await Future.delayed(const Duration(milliseconds: 500));
      }
    } on PlatformException {
      r = 'unsupported';
    }
    if (!mounted) return;
    setState(() => _ar = switch (r) {
          'ready' => _Ar.ready,
          'install_requested' || 'declined' => _Ar.needsInstall,
          'denied' => _Ar.denied,
          _ => _Ar.unsupported,
        });
  }

  void _snack(String m) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _onTap(ARHitResult hit) async {
    final it = _items[_sel];
    try {
      await rootBundle.load(it.model); // fails fast if the .glb is missing from the project
    } catch (_) {
      _snack('Model file missing: ${it.model}. Copy it into assets/ar/ and run again.');
      return;
    }
    try {
      final p = await _controller.placeModel(hit, ModelNode(modelPath: it.model, scale: it.size));
      if (!mounted) return;
      setState(() {
        _placed.add(p);
        _hint = _gestureHint;
      });
      _snack('${it.name} placed. Step back if you cannot see it.');
    } on PlatformException catch (e) {
      if (!mounted) return;
      _snack(e.code == 'NOT_TRACKING'
          ? 'Still finding the floor. Move your phone slowly and try again.'
          : 'Could not place the model: ${e.message ?? e.code}');
    }
  }

  Future<void> _undo() async {
    if (_placed.isEmpty) return;
    final p = _placed.removeLast();
    await _controller.removePlacedModel(p);
    if (mounted) setState(() => _hint = _placed.isEmpty ? _findHint : _gestureHint);
  }

  Future<void> _clear() async {
    if (_placed.isEmpty) return;
    await _controller.clearScene();
    _placed.clear();
    if (mounted) setState(() => _hint = _findHint);
  }

  void _help() => showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('AR Preview'),
          content: const Text(
            'Point the camera at the floor and move your phone slowly until it is detected. '
            'Pick a piece of furniture below and tap the floor to place it.\n\n'
            'Drag it to move, twist with two fingers to rotate and pinch to resize.',
          ),
          actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
        ),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
          child: Column(children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(4, 4, 12, 8),
              child: Row(children: [
                IconButton(onPressed: () => Navigator.maybePop(context), icon: const Icon(Icons.arrow_back_rounded, color: kNavy)),
                const Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('AR Preview', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: kNavy)),
                    Text('See how furniture looks in your space', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12, color: Color(0xFF5A6785))),
                  ]),
                ),
                IconButton(onPressed: _help, icon: const Icon(Icons.help_outline_rounded, color: kNavy)),
              ]),
            ),
            Expanded(child: SizedBox(width: double.infinity, child: _view())),
            _panel(),
          ]),
        ),
      );

  // ------------------------------------------------------------------ AR view / fallback

  Widget _view() {
    if (_ar != _Ar.ready) return _fallback();
    return Stack(children: [
      Positioned.fill(child: ARSceneView(controller: _controller, planeDetection: true, onPlaneTap: _onTap)),
      Positioned(
        left: 12,
        right: 12,
        top: 12,
        child: IgnorePointer(
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(color: Colors.black.withValues(alpha: 0.55), borderRadius: BorderRadius.circular(14)),
            child: Text(_hint, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600)),
          ),
        ),
      ),
    ]);
  }

  Widget _fallback() {
    final (msg, retry) = switch (_ar) {
      _Ar.checking => ('Starting AR…', false),
      _Ar.unsupported => ('This phone does not support ARCore, so live AR is not available.', false),
      _Ar.needsInstall => ('Install "Google Play Services for AR", then open AR Preview again.', true),
      _Ar.denied => ('Camera permission is needed for AR. Allow it and try again.', true),
      _ => ('Live AR works on Android only.', false),
    };
    return Stack(fit: StackFit.expand, children: [
      Image.asset('assets/images/demo/room.jpg', fit: BoxFit.cover, alignment: Alignment.topCenter),
      Container(color: Colors.black.withValues(alpha: 0.45)),
      Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            if (_ar == _Ar.checking) const CircularProgressIndicator(color: Colors.white) else const Icon(Icons.view_in_ar, size: 44, color: Colors.white),
            const SizedBox(height: 14),
            Text(msg, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w600)),
            if (retry) ...[
              const SizedBox(height: 14),
              FilledButton(onPressed: _prepare, child: const Text('Try again')),
            ],
          ]),
        ),
      ),
    ]);
  }

  // ------------------------------------------------------------------ bottom picker

  Widget _panel() => Container(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [BoxShadow(color: kNavy.withValues(alpha: 0.08), blurRadius: 16, offset: const Offset(0, -4))],
        ),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Furniture', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: kNavy)),
          const SizedBox(height: 10),
          SizedBox(
            height: 112,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: _items.length,
              separatorBuilder: (_, __) => const SizedBox(width: 10),
              itemBuilder: (_, i) => _card(i),
            ),
          ),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: _placed.isEmpty ? null : _undo,
                icon: const Icon(Icons.undo_rounded, size: 18),
                label: const Text('Undo'),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: OutlinedButton.icon(
                onPressed: _placed.isEmpty ? null : _clear,
                icon: const Icon(Icons.delete_outline_rounded, size: 18),
                label: const Text('Clear all'),
              ),
            ),
          ]),
        ]),
      );

  Widget _card(int i) {
    final it = _items[i];
    final on = _sel == i;
    return GestureDetector(
      onTap: () => setState(() => _sel = i),
      child: SizedBox(
        width: 104,
        child: Column(children: [
          Stack(children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 160),
              height: 80,
              width: double.infinity,
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                color: const Color(0xFFF4F6FA),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: on ? kBlue : kBorder, width: on ? 2 : 1),
              ),
              child: Image.asset(it.thumb, fit: BoxFit.contain, errorBuilder: (_, __, ___) => const Icon(Icons.chair_outlined, color: kBlue, size: 36)),
            ),
            if (on) const Positioned(right: 4, top: 4, child: CircleAvatar(radius: 9, backgroundColor: kBlue, child: Icon(Icons.check, size: 12, color: Colors.white))),
          ]),
          const SizedBox(height: 4),
          Text(it.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 11, fontWeight: on ? FontWeight.w800 : FontWeight.w500, color: kNavy)),
        ]),
      ),
    );
  }
}